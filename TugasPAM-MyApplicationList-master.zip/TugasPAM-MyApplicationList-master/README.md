# TugasPAM-MyApplicationList
 Tugas Pemrograman Aplikasi Mobile 1 - Membuat Aplikasi android dengan listview, custom listview, dan recyclerview
 
 Berikut tampilannya : 
 ![](Screenshot_1570270101.png)
 ![](Screenshot_1570270150.png) 
 ![](Screenshot_1570270153.png) 
 ![](Screenshot_1570270156.png) 
